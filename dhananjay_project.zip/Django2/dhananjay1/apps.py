from django.apps import AppConfig


class Dhananjay1Config(AppConfig):
    name = 'dhananjay1'
